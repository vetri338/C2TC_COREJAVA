//Program to define Phone interface
package com.tnsif.dayeight.interfaces.instanceofinterface;

public interface Phone {
	void call();

	void sms();
}

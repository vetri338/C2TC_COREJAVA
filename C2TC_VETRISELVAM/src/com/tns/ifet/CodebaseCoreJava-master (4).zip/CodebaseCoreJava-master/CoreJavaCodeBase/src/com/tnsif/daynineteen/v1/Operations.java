//Define FunctionalInterface Operations

package com.tnsif.daynineteen.v1;

@FunctionalInterface
public interface Operations {
	float performArithmetic(int a, int b);
}
